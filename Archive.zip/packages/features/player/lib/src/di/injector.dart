import 'package:feature_player/src/di/injector.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const playerDi = init;
