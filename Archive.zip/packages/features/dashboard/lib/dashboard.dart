export 'package:feature_dashboard/src/dashboard/dashboard_page.dart';
export 'package:feature_dashboard/src/di/injector.dart';
export 'package:feature_dashboard/src/navigation/navigator.dart';
export 'package:feature_dashboard/src/navigation/routes.dart';
