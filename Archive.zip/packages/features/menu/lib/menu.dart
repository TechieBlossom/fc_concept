export 'package:feature_menu/src/di/injector.dart';
export 'package:feature_menu/src/menu/menu_page.dart';
export 'package:feature_menu/src/navigator/routes.dart';
