import 'package:feature_menu/src/di/injector.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const menuDi = init;
