import 'package:feature_compare/src/di/injector.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const compareDi = init;
