import 'package:feature_filter/src/di/injector.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const filterDi = init;
