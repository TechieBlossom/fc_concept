enum NestedFilterType {
  league,
  club,
  nation,
  rarity,
}
