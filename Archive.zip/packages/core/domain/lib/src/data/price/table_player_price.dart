class TablePlayerPrice {
  TablePlayerPrice._();

  static const tablePlayerPrice = 'table_player_price';
  static const eaId = 'eaId';
  static const price = 'price';
  static const overall = 'overall';
}
