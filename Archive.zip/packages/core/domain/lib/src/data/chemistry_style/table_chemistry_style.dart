class TableChemistryStyle {
  TableChemistryStyle._();

  static const tableChemistryStyle = 'table_core_chemistry_style';
  static const id = 'id';
  static const name = 'name';
  static const shortName = 'shortName';
  static const oneChemistryModifier = 'oneChemistryModifier';
  static const twoChemistryModifier = 'twoChemistryModifier';
  static const threeChemistryModifier = 'threeChemistryModifier';
  static const isGkStyle = 'isGkStyle';
  static const charCode = 'charCode';
}
