class TablePlayStyle {
  TablePlayStyle._();

  static const tablePlayStyle = 'table_core_playstyle';
  static const eaId = 'eaId';
  static const name = 'name';
  static const categoryId = 'categoryId';
  static const whoHasIt = 'whoHasIt';
  static const imagePath = 'imagePath';
}
