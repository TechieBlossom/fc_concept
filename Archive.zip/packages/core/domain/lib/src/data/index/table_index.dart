class TableIndex {
  TableIndex._();

  static const tableIndex = 'table_index';
  static const id = 'id';
  static const forwards = 'forwards';
  static const midfielders = 'midfielders';
  static const defenders = 'defenders';
  static const goalkeepers = 'goalkeepers';
}
