class TableRaritySquad {
  TableRaritySquad._();

  static const tableRaritySquad = 'table_core_rarity_squad';
  static const id = 'id';
  static const name = 'name';
  static const rarityGroupId = 'rarityGroupId';
  static const color = 'color';
  static const releaseDate = 'releaseDate';
  static const imagePath = 'imagePath';
}
