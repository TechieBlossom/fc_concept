class TablePosition {
  TablePosition._();

  static const tablePosition = 'table_core_position';
  static const eaId = 'eaId';
  static const label = 'label';
  static const shortLabel = 'shortLabel';
  static const positionTypeId = 'positionTypeId';
  static const positionTypeName = 'positionTypeName';
}
