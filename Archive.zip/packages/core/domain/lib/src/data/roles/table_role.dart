class TableRole {
  TableRole._();

  static const tableRole = 'table_core_role';
  static const eaId = 'eaId';
  static const name = 'name';
  static const positionName = 'positionName';
  static const description = 'description';
  static const isPlus = 'isPlus';
  static const isPlusPlus = 'isPlusPlus';
  static const cleanName = 'cleanName';
}
