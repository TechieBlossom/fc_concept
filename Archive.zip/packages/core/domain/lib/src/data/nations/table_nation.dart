class TableNation {
  TableNation._();

  static const tableNation = 'table_core_nation';
  static const eaId = 'eaId';
  static const name = 'name';
  static const isTop = 'isTop';
  static const imagePath = 'imagePath';
}
