class TableLeague {
  TableLeague._();

  static const tableLeague = 'table_core_league';
  static const eaId = 'eaId';
  static const name = 'name';
  static const isTop = 'isTop';
  static const imagePath = 'imagePath';
  static const imageLightPath = 'imageLightPath';
}
