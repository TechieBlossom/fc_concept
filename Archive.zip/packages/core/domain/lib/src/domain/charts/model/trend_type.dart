enum TrendType {
  up,
  down,
  flat,
}
