class LoginRequestModel {
  LoginRequestModel({
    required this.password,
    required this.email,
  });

  final String email;
  final String password;
}
