export 'package:core_design/src/templates/loading_list.dart';
