import 'package:core_api_client/src/di/injector.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const apiClientDi = init;
