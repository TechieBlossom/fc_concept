const supabaseUrl = 'https://ilvbpyniqpybqtgtnuam.supabase.co';
const supabaseAnon =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlsdmJweW5pcXB5YnF0Z3RudWFtIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NzkyMjg4NTEsImV4cCI6MTk5NDgwNDg1MX0.8v5XxdgrK4HRk3gAHrCX8TggGN2AB0fWd8btpOBjpQM';

const futApiKey = 'f4a43e47-dfe3-46f6-9926-b3dc721d28fc';
const wiredashProjectId = 'fut-maidaan-7jbiwfj';
const wiredashSecret = 'xrxgRLNodnHuR86DThFUWXLB-cOy0xRO';
