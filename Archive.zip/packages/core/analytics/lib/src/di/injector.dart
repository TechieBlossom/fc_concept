import 'package:core_analytics/src/di/injector.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const analyticsDi = init;
