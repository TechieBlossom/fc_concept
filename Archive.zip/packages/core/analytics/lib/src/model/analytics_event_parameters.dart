mixin AnalyticsEventParameters {
  Map<String, Object> get analyticsParameters;
}
