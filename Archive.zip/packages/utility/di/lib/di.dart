export 'package:get_it/get_it.dart';
export 'package:utility_di/src/configure_dependencies.dart';
export 'package:utility_di/src/get_it.dart';
