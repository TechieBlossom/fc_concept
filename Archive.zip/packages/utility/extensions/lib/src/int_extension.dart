extension XInt on int? {
  int orZero() => this ?? 0;
}
