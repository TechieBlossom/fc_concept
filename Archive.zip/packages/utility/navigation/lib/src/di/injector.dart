import 'package:injectable/injectable.dart';
import 'package:utility_navigation/src/di/injector.config.dart';

@InjectableInit(asExtension: false)
const navigationDi = init;
