import 'package:fc_concept/di/injection.config.dart';
import 'package:injectable/injectable.dart';

@InjectableInit(asExtension: false)
const appDi = init;
